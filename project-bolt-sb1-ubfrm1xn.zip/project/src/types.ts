export interface Work {
  id?: number;
  url: string;
  title: string;
  description: string;
  created_at?: string;
}

export interface User {
  id: string;
  email: string;
}

export interface AuthState {
  user: User | null;
  loading: boolean;
}