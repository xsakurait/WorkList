import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlusCircle } from 'lucide-react';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';
import type { Work } from '../types';

const AddWork: React.FC = () => {
  const navigate = useNavigate();
  const { authState } = useAuth();
  const [newWork, setNewWork] = useState<Work>({
    url: '',
    title: '',
    description: ''
  });
  const [error, setError] = useState<string>('');

  // 未認証の場合はログインページにリダイレクト
  React.useEffect(() => {
    if (!authState.loading && !authState.user) {
      navigate('/login');
    }
  }, [authState, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newWork.description.length > 100) {
      setError('説明は100文字以内で入力してください');
      return;
    }
    try {
      await axios.post('http://localhost:8000/api/works/', newWork);
      navigate('/');
    } catch (err) {
      setError('作品の追加に失敗しました');
    }
  };

  if (authState.loading) {
    return <div>読み込み中...</div>;
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">新規作品の追加</h1>
      
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md">
        {error && <p className="text-red-500 mb-4">{error}</p>}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              URL
            </label>
            <input
              type="url"
              value={newWork.url}
              onChange={(e) => setNewWork({ ...newWork, url: e.target.value })}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              タイトル
            </label>
            <input
              type="text"
              value={newWork.title}
              onChange={(e) => setNewWork({ ...newWork, title: e.target.value })}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              説明（100文字以内）
            </label>
            <textarea
              value={newWork.description}
              onChange={(e) => setNewWork({ ...newWork, description: e.target.value })}
              required
              maxLength={100}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
              rows={3}
            />
            <p className="text-sm text-gray-500 mt-1">
              {newWork.description.length}/100文字
            </p>
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
          >
            <PlusCircle className="w-5 h-5" />
            追加
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddWork;