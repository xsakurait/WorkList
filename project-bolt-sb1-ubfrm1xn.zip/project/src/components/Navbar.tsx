import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { LogOut, PlusCircle } from 'lucide-react';

const Navbar: React.FC = () => {
  const { authState, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/');
    } catch (error) {
      console.error('ログアウトエラー:', error);
    }
  };

  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-4xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <Link to="/" className="text-xl font-bold text-gray-900">
            作品リスト
          </Link>
          <div className="flex items-center space-x-4">
            {authState.user ? (
              <>
                <Link
                  to="/add"
                  className="flex items-center gap-1 text-blue-600 hover:text-blue-700"
                >
                  <PlusCircle className="w-5 h-5" />
                  <span>作品を追加</span>
                </Link>
                <button
                  onClick={handleSignOut}
                  className="flex items-center gap-1 text-gray-600 hover:text-gray-700"
                >
                  <LogOut className="w-5 h-5" />
                  <span>ログアウト</span>
                </button>
              </>
            ) : (
              <Link
                to="/login"
                className="text-blue-600 hover:text-blue-700"
              >
                ログイン
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;