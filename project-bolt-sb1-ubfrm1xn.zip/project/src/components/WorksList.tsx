import React, { useState, useEffect } from 'react';
import axios from 'axios';
import type { Work } from '../types';

const WorksList: React.FC = () => {
  const [works, setWorks] = useState<Work[]>([]);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    const fetchWorks = async () => {
      try {
        const response = await axios.get('http://localhost:8000/api/works/');
        setWorks(response.data);
      } catch (err) {
        setError('作品の取得に失敗しました');
      }
    };

    fetchWorks();
  }, []);

  if (error) {
    return <div className="text-red-500">{error}</div>;
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">作品一覧</h1>
      <div className="grid gap-6 md:grid-cols-2">
        {works.map((work) => (
          <div key={work.id} className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-2">{work.title}</h3>
            <a
              href={work.url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 hover:underline mb-2 block"
            >
              {work.url}
            </a>
            <p className="text-gray-600">{work.description}</p>
            {work.created_at && (
              <p className="text-sm text-gray-500 mt-2">
                投稿日: {new Date(work.created_at).toLocaleDateString('ja-JP')}
              </p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default WorksList;