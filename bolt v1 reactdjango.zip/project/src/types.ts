export interface Work {
  id?: number;
  url: string;
  title: string;
  description: string;
}